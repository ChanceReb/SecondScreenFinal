package com.example.flingphone;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.net.URL;

public class amazonitem {

    String asin;
    String imageurl;
    String amazonurl;
    Bitmap bitmap;

    public amazonitem(String asin, String url){
        this.asin = asin;
        this.imageurl = url;
        this.amazonurl = "http://www.amazon.com/dp/" + asin;
        Thread download = new Thread( new downloader());
        download.start();
        try {
            download.join();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private class downloader implements Runnable{

        @Override
        public void run() {
            try{

                URL newurl = new URL(imageurl);
                Log.e("add image", "url = " + newurl.toString());
                bitmap  = BitmapFactory.decodeStream(newurl.openConnection().getInputStream());

            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }

}

package com.example.flingphone;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferNetworkLossHandler;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartResult;

/* TODO if I want to use these need to update gradel files with new stuff
import com.amplifyframework.core.Amplify;
import com.amplifyframework.core.ResultListener;
import com.amplifyframework.storage.result.StorageDownloadFileResult;
import com.amplifyframework.storage.result.StorageListResult;
import com.amplifyframework.storage.result.StorageUploadFileResult;
*/
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.List;

public class UploadActivity extends AppCompatActivity {

    private final String TAG = UploadActivity.class.getSimpleName();

    private String storageBucketName;
    private String region;
    private String photoPath;
    private String jsonPath;
    private String jsonName;
    ProgressBar mProgressBar;
    AmazonS3Client s3Client;
    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // come from upload button in image activity
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        mProgressBar = findViewById(R.id.progressBar);
        setStorageInfo();
        photoPath = getIntent().getStringExtra("path");
        Log.e(TAG, photoPath);
        File test = new File(photoPath);
        String tmp = test.getName();
        jsonName = tmp.substring(0, tmp.length() - 4) + ".json";
        jsonPath = "public/json/rekresults-" + jsonName;

        uploadAndSave();
    }

    private void setStorageInfo() {
        JSONObject s3Config = new AWSConfiguration(this)
                .optJsonObject("S3TransferUtility");
        try {
            storageBucketName = s3Config.getString("Bucket");
            region = s3Config.getString("Region");
        } catch (JSONException e) {
            Log.e(TAG, "Can't find S3 bucket", e);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(UploadActivity.this,
                            "Error: Can't find S3 bucket. \nHave you run 'amplify add storage'? ",
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    // Checks permissions for upload (required)
    private void uploadAndSave() {
        if (photoPath != null) {
            Log.e(TAG, "photoPath is not null" + photoPath);
            // For higher Android levels, we need to check permission at runtime
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission is not granted
                Log.d(TAG, "READ_EXTERNAL_STORAGE permission not granted! Requesting...");
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        1);
            }
            // Upload a photo first. We will only call save on its successful callback.
            uploadWithTransferUtility(photoPath);

        }
    }
    private String getS3Key(String localPath) {
        //We have read and write ability under the public folder
        return "public/images/" + new File(localPath).getName();
    }


    public void uploadWithTransferUtility(String localPath) {
        String key = getS3Key(localPath);

        Log.d(TAG, "Uploading file from " + localPath + " to " + key);
        Log.e(TAG, "key is: " + key);
        File newfile = new File(localPath);
        // don't do anything with this just put it in to make error msgs happy
        TransferNetworkLossHandler.getInstance(UploadActivity.this);
        final TransferObserver uploadObserver =
                ClientFactory.transferUtility().upload(
                        key,
                        newfile);

        // Attach a listener to the observer to get state update and progress notifications
        uploadObserver.setTransferListener(new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {
                if (TransferState.COMPLETED == state) {
                    // Handle a completed upload.
                    Log.d(TAG, "Upload is completed. ");
                    Thread tDownload = new Thread(new download());
                    tDownload.start();
                    //mHandler.postDelayed(download, 7000);

                }
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                float percentDonef = ((float) bytesCurrent / (float) bytesTotal) * 100;
                int percentDone = (int)percentDonef;

                Log.d(TAG, "ID:" + id + " bytesCurrent: " + bytesCurrent
                        + " bytesTotal: " + bytesTotal + " " + percentDone + "%");
            }

            @Override
            public void onError(int id, Exception ex) {
                // Handle errors
                Log.e(TAG, "Failed to upload photo. ", ex);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(UploadActivity.this, "Failed to upload photo", Toast.LENGTH_LONG).show();
                    }
                });
            }

        });
    }
    public void downloadWithTransferUtility() {

        final File newfile = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + "/" + jsonName);
        Log.e(TAG, "json path:" + jsonPath);
        Log.e(TAG, "directory: " + newfile.getAbsolutePath());
        TransferNetworkLossHandler.getInstance(UploadActivity.this);
        TransferObserver downloadObserver =
                ClientFactory.transferUtility().download(
                        jsonPath,
                        newfile);

        // Attach a listener to the observer to get state update and progress notifications
        downloadObserver.setTransferListener(new TransferListener() {

            @Override
            public void onStateChanged(int id, TransferState state) {
                if (TransferState.COMPLETED == state) {
                    Log.d(TAG, "Download complete. ");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(UploadActivity.this, "Analysis complete!", Toast.LENGTH_LONG).show();
                            Intent displayBounding = new Intent(UploadActivity.this, boundingBoxesActivity.class);
                            displayBounding.putExtra("path", photoPath);
                            displayBounding.putExtra("labels", getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + "/" + jsonName);
                            startActivity(displayBounding);
                        }
                    });
                }
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                float percentDonef = ((float) bytesCurrent / (float) bytesTotal) * 100;
                int percentDone = (int)percentDonef;

                Log.d(TAG, "ID:" + id + " bytesCurrent: " + bytesCurrent
                        + " bytesTotal: " + bytesTotal + " " + percentDone + "%");
            }

            @Override
            public void onError(int id, Exception ex) {
                // Handle errors
                Log.e(TAG, "Failed to download photo. ", ex);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(UploadActivity.this, "Failed to download json", Toast.LENGTH_LONG).show();
                    }
                });
            }

        });
    }
    class download implements Runnable {
        @Override
        public void run(){
            boolean found = false;
            List<S3ObjectSummary> s3List;
            AWSMobileClient mobileClient = AWSMobileClient.getInstance();
            Log.e("username", mobileClient.getUsername());
            Log.e("IdentityId", mobileClient.getIdentityId());
            CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                    getApplicationContext(),
                    "us-east-1:1af67d5e-e932-431e-8ad8-bca9dc9154fe",
                    Regions.US_EAST_1);
            //credentialsProvider.refresh();
            s3Client = new AmazonS3Client(credentialsProvider);
            S3Object test;
            while (found == false) {
                try {
                    test = s3Client.getObject(storageBucketName, jsonPath);
                    found = true;
                    Log.e("gotcha", test.toString());
                }
                catch (AmazonS3Exception e) {
                    Log.e("oops", "not there yet");
                }
            }
            Log.e("Download starting", "found match");
            downloadWithTransferUtility();

        }
    }
}
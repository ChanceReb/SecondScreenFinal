package com.example.flingphone;

import androidx.appcompat.app.AppCompatActivity;
import com.amazon.whisperplay.fling.media.controller.RemoteMediaPlayer;
import com.amazon.whisperplay.fling.media.controller.DiscoveryController;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;


public class ScreenshotActivity extends AppCompatActivity {

    Button btnScreenshot;
    DiscoveryController mController;
    RemoteMediaPlayer mCurrentDevice;
    ProgressBar mProgressBar;
    String device2connect;
    String ip;
    String photoPath;

//    private DiscoveryController.IDiscoveryListener mDiscovery = new DiscoveryController.IDiscoveryListener() {
//        @Override
//        public void playerDiscovered(RemoteMediaPlayer player) {
//            //add media player to the application’s player list.
//            if(player.getName().equals(device2connect)){
//                mCurrentDevice = player;
//            }
//        }
//        @Override
//        public void playerLost(RemoteMediaPlayer player) {
//            //remove media player from the application’s player list.
//        }
//        @Override
//        public void discoveryFailure() {
//            // Toast.makeText(getApplicationContext(), "Discovery Failure", Toast.LENGTH_LONG).show();
//
//        }
//    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screenshot);
        mProgressBar = findViewById(R.id.progressBar);
        mController = new DiscoveryController(getApplicationContext());
        device2connect = getIntent().getStringExtra("device name");
        ip = getIntent().getStringExtra("ip");
        btnScreenshot = findViewById(R.id.btn_take_screenshot);
        mCurrentDevice = MainActivity.mCurrentDevice;
        btnScreenshot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (mCurrentDevice != null) {
                    takeScreenshot();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //mController.start("com.your.organization.TVPlayer", mDiscovery);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mController.stop();
    }

    private void takeScreenshot() {
        //TODO look into run on ui thread
        btnScreenshot.setVisibility(View.INVISIBLE);
        mProgressBar.setVisibility(View.VISIBLE);
        mCurrentDevice.sendCommand(ip).getAsync(new ScreenshotActivity.ErrorResultHandler("send command", "send command failure"));
        // new thread to run communication to FireTV for file transfer
        Thread t = new Thread(new ScreenshotActivity.Server());
        t.start();
        try {
            t.join();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        // TODO might need to add timer to make transitions smoother
        //Log.d(TAG, "done waiting for transfer thread");

        Intent viewimage = new Intent(ScreenshotActivity.this, ImageActivity.class);
        viewimage.putExtra("path", photoPath);
        // TODO better way to do this then pass these to image and image passes back?
        viewimage.putExtra("device name", device2connect);
        viewimage.putExtra("ip", ip);
        startActivity(viewimage);
    }

    private class ErrorResultHandler implements RemoteMediaPlayer.FutureListener<Void> {
        private String mCommand;
        private String mMsg;

        ErrorResultHandler(String command, String msg) {
            mCommand = command;
            mMsg = msg;
        }

        @Override
        public void futureIsNow(Future<Void> result) {
            String TAG = "Screenshot Activity";
            try {
                result.get();
                Log.i(TAG, mCommand + ": successful");
            } catch(ExecutionException e) {
                Log.i(TAG, mMsg);
                e.printStackTrace();
            } catch(Exception e) {
                Log.i(TAG, mMsg);
                e.printStackTrace();
            }
        }
    }

    class Server implements Runnable{

        @Override
        public void run() {
            try{
                ServerSocket serverSocket = new ServerSocket(8888);
                Socket client = serverSocket.accept();

                byte[] buffer = new byte[1024];
                int read = 0;
                InputStream instream = client.getInputStream();

                Date now = new Date();
                android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
                // use class variable photoPath so can access elsewhere in file
                photoPath = getExternalFilesDir(Environment.DIRECTORY_PICTURES).toString() + "/" + now + ".jpg";
                FileOutputStream fos = new FileOutputStream(photoPath);

                read = instream.read(buffer);

                while(read > 0){
                    fos.write(buffer, 0, read);
                    read = instream.read(buffer);
                }

                instream.close();
                fos.close();
                //Log.d(TAG, "file transfer completed...");

            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}

package com.example.flingphone;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.flingphone.R;
import com.example.flingphone.amazonitem;
import com.example.flingphone.myadapter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.List;

public class ProductSelectActivity extends AppCompatActivity {

    private StaggeredGridLayoutManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycleractivity);

        String response = getIntent().getStringExtra("response");
        RecyclerView recyclerView = findViewById(R.id.recyclergrid);

        manager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(manager);

        //List<amazonitem> list = populatelist();
        List<amazonitem> list = parseDeepVisionJson(response);

        myadapter adapter = new myadapter(list, this);

        recyclerView.setAdapter(adapter);

    }

    private List<amazonitem> populatelist(){

        List<amazonitem> items = new ArrayList<>();

        items.add(new amazonitem("B0792FVCJ3", "https://images-na.ssl-images-amazon.com/images/I/81F0%2BzWde3L._AC_UX466_.jpg"));
        items.add(new amazonitem("B07PDLYX94", "https://images-na.ssl-images-amazon.com/images/I/91FADQFiRyL._AC_UL320_SR222,320_.jpg"));
        items.add(new amazonitem("B00SMJOETO", "https://images-na.ssl-images-amazon.com/images/I/619s5hELmJL._AC_UX500_.jpg"));
        items.add(new amazonitem("B079D34YFT", "https://images-na.ssl-images-amazon.com/images/I/71MCy%2BpsZJL._AC_UX466_.jpg"));
        return items;
    }

    public List<amazonitem>  parseDeepVisionJson(String response){
        List<amazonitem> items = new ArrayList<>();

        JSONParser jsonParser = new JSONParser();
        try {
            JSONArray arr = (JSONArray) jsonParser.parse(response);
            for (Object o : arr){
                JSONObject obj = (JSONObject) o;
                JSONArray images = (JSONArray) obj.get("similar_images");
                for (Object im : images){
                    JSONObject image = (JSONObject) im;
                    String alias = (String) image.get("image_alias");
                    String[] alias_split = alias.split(" ");
                    items.add(new amazonitem(alias_split[0], alias_split[1]));
                }
            }
        }
        catch (ParseException e){
            e.printStackTrace();
            Log.e("bad", "deep vision json parse error");
        }
        return items;
    }

}

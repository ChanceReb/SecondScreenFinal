package com.example.flingphone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Region;
import android.os.Bundle;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;

public class ImageActivity extends AppCompatActivity {

    private ImageView screenshot;
    private Button uploadbutton;
    private Button CropButton;
    private Button RetryCrop;
    private String path;

    private Bitmap localmap;
    private Rect cropBounds;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        screenshot = findViewById(R.id.imagedisplay);
        uploadbutton = findViewById(R.id.beginuploadbutton);
        RetryCrop = findViewById(R.id.retrycrop);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        path = getIntent().getStringExtra("path");
        setScreenshot(path);

        CropButton = findViewById(R.id.CropImage);

        CropButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                if(cropBounds != null){
                    int width = Math.abs(cropBounds.left - cropBounds.right);
                    int height = Math.abs(cropBounds.top - cropBounds.bottom);
                    Bitmap cropped = Bitmap.createBitmap(localmap, cropBounds.left, cropBounds.top, width, height);
                    localmap = cropped;
                    screenshot.setImageBitmap(cropped);
                    cropBounds = null;

                    try {
                        File croppedimg = new File(path.substring(0, path.length() - 4) +  "cropped.jpg");
                        FileOutputStream outputStream = new FileOutputStream(croppedimg);
                        localmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                        outputStream.flush();
                        outputStream.close();
                    } catch (Exception e){
                        e.printStackTrace();
                    }

                    RetryCrop.setVisibility(View.VISIBLE);
                    CropButton.setVisibility(View.INVISIBLE);
                    uploadbutton.setVisibility(View.VISIBLE);

                    RetryCrop.setClickable(true);
                    CropButton.setClickable(false);
                    uploadbutton.setClickable(true);

                }
            }
        });

        RetryCrop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setScreenshot(path);

                RetryCrop.setVisibility(View.INVISIBLE);
                CropButton.setVisibility(View.VISIBLE);
                uploadbutton.setVisibility(View.INVISIBLE);

                RetryCrop.setClickable(false);
                uploadbutton.setClickable(false);
                CropButton.setClickable(true);
            }
        });

        RetryCrop.setClickable(false);

        uploadbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startUpload = new Intent(ImageActivity.this, UploadActivity.class);
                startUpload.putExtra("path", path.substring(0, path.length() - 4) +  "cropped.jpg");
                startActivity(startUpload);
            }
        });

        uploadbutton.setClickable(false);

    }

    public void setScreenshot(String path) {
        File image = new File(path);
        if (image.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(image.getAbsolutePath());
            localmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);

            screenshot.setImageBitmap(localmap);

            screenshot.setOnTouchListener(fancyListener());
        }
    }

    private View.OnTouchListener fancyListener(){

        return new View.OnTouchListener() {
            Point p1;
            Point p2;
            Canvas canvas;
            Paint paint = new Paint();
            Matrix inverse = new Matrix();
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                screenshot.getImageMatrix().invert(inverse);

                float[] coords = {event.getX(), event.getY()};

                inverse.mapPoints(coords);

                int X = (int)coords[0];
                int Y = (int)coords[1];

                switch(event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        p1 = new Point(X, Y);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        p2 = new Point(X,Y);
                        if(X > localmap.getWidth()){
                            p2.x = localmap.getWidth();
                        } else if (X < 0){
                            p2.x = 0;
                        }

                        if(Y > localmap.getHeight()){
                            p2.y = localmap.getHeight();
                        } else if (Y < 0){
                            p2.y = 0;
                        }
                        v.invalidate();

                        Bitmap newmap = localmap.copy(Bitmap.Config.ARGB_8888, true);
                        canvas = new Canvas(newmap);
                        paint.setColor(Color.rgb(255, 255, 255));
                        paint.setStyle(Paint.Style.STROKE);
                        paint.setStrokeWidth(5);
                        //Rect newRect = new Rect(p1.x,p1.y, p2.x, p2.y);

                        if(Math.abs(p1.x - p2.x) < 80){
                            p2.x += 80 - Math.abs(p1.x - p2.x);
                        }

                        if(Math.abs(p1.y - p2.y) < 80){
                            p2.y += 80 - Math.abs(p1.y - p2.y);
                        }

                        cropBounds = new Rect(p1.x,p1.y, p2.x, p2.y);//new Rect(jpg1.x, jpg1.y, jpg2.x, jpg2.y);

                        canvas.drawRect(cropBounds, paint);

                        canvas.clipRect(cropBounds, Region.Op.DIFFERENCE);
                        canvas.drawARGB(200, 0,0,0);
                        canvas.clipRect(
                                new Rect(0,0,canvas.getWidth(), canvas.getHeight()),
                                Region.Op.DIFFERENCE);


                        screenshot.setImageBitmap(newmap);

                        break;

                    default:
                        break;
                }

                return true;
            }
        };
    }
}
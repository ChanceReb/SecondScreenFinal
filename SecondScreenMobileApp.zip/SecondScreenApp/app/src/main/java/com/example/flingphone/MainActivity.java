package com.example.flingphone;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.amazon.whisperplay.fling.media.controller.RemoteMediaPlayer;
import com.amazon.whisperplay.fling.media.controller.DiscoveryController;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();

    private ListView deviceView;
    private TextView target;
    private String ip;
    private String photoPath;
    private Toolbar toolbar;
    //private ImageButton showdevices;

    private MenuItem whisperplay;

    private ProgressBar mProgressBar;
    private Button btnScreenshot;
    DiscoveryController mController;
    public static RemoteMediaPlayer mCurrentDevice;

    List<RemoteMediaPlayer> mDeviceList = new ArrayList<>();
    String[] deviceNames = new String[mDeviceList.size()];


    private DiscoveryController.IDiscoveryListener mDiscovery = new DiscoveryController.IDiscoveryListener() {
        @Override
        public void playerDiscovered(RemoteMediaPlayer player) {
            //add media player to the application’s player list.
            if(!mDeviceList.contains(player)){
                mDeviceList.add(player);

                deviceNames = new String[mDeviceList.size()];
                int i = 0;
                for(RemoteMediaPlayer remoteMediaPlayer : mDeviceList){
                    deviceNames[i] = remoteMediaPlayer.getName();
                    i++;
                }

                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(deviceNames.length > 0){
                            //showdevices.setVisibility(View.VISIBLE);
                            whisperplay.setVisible(true);
                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, deviceNames);
                        deviceView.setAdapter(adapter);
                    }
                });

            }
        }
        @Override
        public void playerLost(RemoteMediaPlayer player) {
            //remove media player from the application’s player list.
            if(mDeviceList.contains(player)){
                mDeviceList.remove(player);

                deviceNames = new String[mDeviceList.size()];
                int i = 0;
                for(RemoteMediaPlayer remoteMediaPlayer : mDeviceList){
                    deviceNames[i] = remoteMediaPlayer.getName();
                    i++;
                }

                //ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, deviceNames);
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, deviceNames);
                        deviceView.setAdapter(adapter);
                    }


                });

                if (mCurrentDevice.equals(player)){
                    //showdevices.setImageResource(R.drawable.ic_whisperplay_default_light_18dp);
                    whisperplay.setIcon(R.drawable.ic_whisperplay_default_light_18dp);
                    Toast.makeText(getApplicationContext(), "disconnected from " + mCurrentDevice.getName(), Toast.LENGTH_LONG).show();
                    mCurrentDevice = null;
                }
            }
        }
        @Override
        public void discoveryFailure() {
            // Toast.makeText(getApplicationContext(), "Discovery Failure", Toast.LENGTH_LONG).show();

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setSupportActionBar(toolbar);
        ClientFactory.init(this);
        WifiManager wifiMan = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInf = wifiMan.getConnectionInfo();
        int ipAddress = wifiInf.getIpAddress();
        ip = String.format("%d.%d.%d.%d", (ipAddress & 0xff),(ipAddress >> 8 & 0xff),(ipAddress >> 16 & 0xff),(ipAddress >> 24 & 0xff));
        setupUI();

    }

    @Override
    protected void onResume() {
        super.onResume();
        mController.start("com.your.organization.TVPlayer", mDiscovery);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mController.stop();
    }

    private void setupUI(){
        deviceView = findViewById(R.id.deviceList);
        mController = new DiscoveryController(getApplicationContext());
        target = findViewById(R.id.target);
        mProgressBar = findViewById(R.id.progressBar);
        toolbar = findViewById(R.id.toolbar);
        //showdevices = findViewById(R.id.whisperplay);
        btnScreenshot = findViewById(R.id.btn_take_screenshot);

        //showdevices.setVisibility(View.INVISIBLE);
        deviceView.setVisibility(View.INVISIBLE);

        setSupportActionBar(toolbar);

        deviceView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mCurrentDevice = mDeviceList.get(position);
                try{
                    //oast.makeText(getApplicationContext(), "ismuted(): " + mCurrentDevice.getName(), Toast.LENGTH_LONG).show();
                    //TODO put this TextView on next screen for short pop-up?
                    target.setText("connected to " + mCurrentDevice.getName());
                    //showdevices.setImageResource(R.drawable.ic_whisperplay_default_blue_light_18dp);
                    whisperplay.setIcon(R.drawable.ic_whisperplay_default_blue_light_18dp);

                    //Intent screenshotintent = new Intent(MainActivity.this, ScreenshotActivity.class);
                    //screenshotintent.putExtra("device name", mCurrentDevice.getName());

                    //screenshotintent.putExtra("ip", ip);
                    //startActivity(screenshotintent);

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        });



        btnScreenshot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (mCurrentDevice != null) {
                    takeScreenshot();
                }
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        whisperplay = menu.findItem(R.id.whisperplay);
        whisperplay.setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        if(item.getItemId() == R.id.whisperplay){

            if (deviceView.getVisibility() == View.VISIBLE){


                ObjectAnimator animator = ObjectAnimator.ofFloat(deviceView,
                        "translationY",
                        (float) -deviceView.getHeight());

                animator.setDuration(350);

                animator.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        deviceView.setVisibility(View.INVISIBLE);
                    }
                });
                animator.start();

            } else {
                deviceView.setVisibility(View.VISIBLE);

                ObjectAnimator animator = ObjectAnimator.ofFloat(deviceView,
                        "translationY",
                        (float) deviceView.getHeight());

                animator.setDuration(350);
                animator.start();
            }


        }

        return true;
    }

    private void takeScreenshot() {
        //TODO look into run on ui thread
        //btnScreenshot.setVisibility(View.INVISIBLE);
        //mProgressBar.setVisibility(View.VISIBLE);
        mCurrentDevice.sendCommand(ip).getAsync(new ErrorResultHandler("send command", "send command failure"));
        // new thread to run communication to FireTV for file transfer
        Thread t = new Thread(new Server());
        t.start();

        //try {
        //    t.join();
        //}
        //catch (InterruptedException e) {
        //    e.printStackTrace();
        //}
        // TODO might need to add timer to make transitions smoother
        //Log.d(TAG, "done waiting for transfer thread");

        //Intent viewimage = new Intent(getApplicationContext(), ImageActivity.class);
        //viewimage.putExtra("path", photoPath);
        // TODO better way to do this then pass these to image and image passes back?
//        viewimage.putExtra("device name", device2connect);
//        viewimage.putExtra("ip", ip);
        // startActivity(viewimage);
    }

    private class ErrorResultHandler implements RemoteMediaPlayer.FutureListener<Void> {
        private String mCommand;
        private String mMsg;

        ErrorResultHandler(String command, String msg) {
            mCommand = command;
            mMsg = msg;
        }

        @Override
        public void futureIsNow(Future<Void> result) {
            String TAG = "Screenshot Activity";
            try {
                result.get();
                Log.i(TAG, mCommand + ": successful");
            } catch(ExecutionException e) {
                Log.i(TAG, mMsg);
                e.printStackTrace();
            } catch(Exception e) {
                Log.i(TAG, mMsg);
                e.printStackTrace();
            }
        }
    }

    class Server implements Runnable{



        @Override
        public void run() {
            try{
                ServerSocket serverSocket = new ServerSocket(8888);
                Socket client = serverSocket.accept();

                byte[] buffer = new byte[1024];
                int read = 0;
                InputStream instream = client.getInputStream();

                Date now = new Date();
                android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
                // use class variable photoPath so can access elsewhere in file
                photoPath = getExternalFilesDir(Environment.DIRECTORY_PICTURES).toString() + "/" + now + ".jpg";
                FileOutputStream fos = new FileOutputStream(photoPath);

                read = instream.read(buffer);

                while(read > 0){
                    fos.write(buffer, 0, read);
                    read = instream.read(buffer);
                }

                instream.close();
                fos.close();
                Log.d(TAG, "file transfer completed...");

                client.close();
                serverSocket.close();

                Log.e("sockets closed", "sockets closed!");

            } catch (Exception e){
                e.printStackTrace();
            } finally {
                Intent viewimage = new Intent(getApplicationContext(), ImageActivity.class);
                viewimage.putExtra("path", photoPath);
                startActivity(viewimage);

            }
        }
    }


}

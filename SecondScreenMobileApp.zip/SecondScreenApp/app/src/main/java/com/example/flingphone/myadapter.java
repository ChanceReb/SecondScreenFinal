package com.example.flingphone;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class myadapter extends RecyclerView.Adapter<myadapter.ButtonViewHolder> {

    private List<amazonitem> itemList;
    private Context context;

    public class ButtonViewHolder extends RecyclerView.ViewHolder{

        public ImageButton imageButton;

        public ButtonViewHolder(View itemView){
            super(itemView);
            imageButton = itemView.findViewById(R.id.linkbutton);
        }

    }

    public myadapter(List<amazonitem> itemList, Context context) {
        this.itemList = itemList;
        this.context = context;
    }

    @NonNull
    @Override
    public ButtonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.amazonitem, null);
        ButtonViewHolder buttonViewHolder = new ButtonViewHolder(layoutView);

        return buttonViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ButtonViewHolder holder, final int position) {

        holder.imageButton.setImageBitmap(itemList.get(position).bitmap);
        holder.imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(itemList.get(position).amazonurl));
                context.startActivity(browserIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

//    private class downloader implements Runnable{
//
//        int position;
//        ButtonViewHolder holder;
//
//        public downloader(int position, ButtonViewHolder holder) {
//            this.position = position;
//            this.holder = holder;
//        }
//
//        @Override
//        public void run() {
//            Bitmap bitmap = null;
//            try{
//
//                URL newurl = new URL(itemList.get(position).url);
//                Log.e("add image", "url = " + newurl.toString());
//                bitmap  = BitmapFactory.decodeStream(newurl.openConnection().getInputStream());
//
//                holder.imageButton.setImageBitmap(bitmap);
//                notifyDataSetChanged();
//            } catch (Exception e){
//                e.printStackTrace();
//            }
//        }
//    }


}

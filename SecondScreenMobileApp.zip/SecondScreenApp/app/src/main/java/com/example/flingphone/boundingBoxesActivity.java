package com.example.flingphone;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.amazonaws.mobileconnectors.s3.transferutility.TransferType;
import com.example.flingphone.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;

import org.jetbrains.annotations.NotNull;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class boundingBoxesActivity extends AppCompatActivity {

    String imagepath;
    String jsonpath;
    ArrayList<BoundingBox> boundingBoxes = new ArrayList<>();
    ImageView screenshot;
    TextView clicked;
    private Button vSearch;
    private BoundingBox lastBoundingBox;

    private static ArrayList<BoundingBox> clickedBoxes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bounding_boxes);
        screenshot = findViewById(R.id.imagedisplay);
        clicked = findViewById(R.id.clicked);
        vSearch = findViewById(R.id.visualsearch);

        visualSearchCall();

        imagepath = getIntent().getStringExtra("path");
        jsonpath = getIntent().getStringExtra("labels");
        buildImage(imagepath, jsonpath);
    }

    class  visualSearchRequest implements  Runnable {
        @Override
        public void run() {
            OkHttpClient client;
            RequestBody formBodyImage;
            byte[] imgBytes;
            String url = "http://api.visualintelligence.deepvisionai.com/search";
            String datasetId = getString(R.string.dataset_fashion);
            String apikey = getString(R.string.deepvision_api_key);
            String mode = "default";
            String responseStr = "";
            String b64Image = "data:image/png;base64,";
            File image = new File(imagepath);
            Bitmap bitmap = BitmapFactory.decodeFile(image.getAbsolutePath());

            // crop screenshot using bounding box that user selected
            if (lastBoundingBox != null){
                Rect crop = lastBoundingBox.box;
                bitmap = bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height());
            }

            // probably surround with try/catch
            ByteArrayOutputStream imgByteStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, imgByteStream);
            imgBytes = imgByteStream.toByteArray();
            b64Image += Base64.getEncoder().encodeToString(imgBytes);

            client = new OkHttpClient();
            formBodyImage = new FormBody.Builder()
                    .add("image", b64Image)
                    .add("dataset_id", datasetId)
                    .add("modes", mode)
                    .build();

            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("api-key", apikey)
                    .post(formBodyImage)
                    .build();
            Call myCall = client.newCall(request);
            try {
                Response myResponse = myCall.execute();
                responseStr = myResponse.body().string();
                Log.e("execute", "executed?");
                Log.e("response", responseStr);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Intent i = new Intent(boundingBoxesActivity.this, ProductSelectActivity.class);
            i.putExtra("response", responseStr);
            startActivity(i);
        }
    }

    public void visualSearchCall() {
        vSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // start up deepvision thread
                //mHandler.post(deepvision);

                Log.e("starting request", "got inside button onClick");
                Thread dvRequest = new Thread(new visualSearchRequest());
                dvRequest.start();
            }
        });
    }

    public void parseRekognitionJSON(Bitmap bitmap){
        int image_width = bitmap.getWidth();
        int image_height = bitmap.getHeight();
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(jsonpath)){
            try {
                JSONObject obj = (JSONObject) jsonParser.parse(reader);
                JSONArray labels = (JSONArray) obj.get("labels");
                Iterator<?> it = labels.iterator();
                while (it.hasNext()) {
                    JSONObject inst = (JSONObject) it.next();
                    for (Object key : inst.keySet()) {
                        JSONObject box = (JSONObject) inst.get(key);
                        int left = (int) (Float.parseFloat((String) box.get("Left")) * image_width);
                        int top = (int) (Float.parseFloat((String) box.get("Top")) * image_height);
                        int right = (int) (left + Float.parseFloat((String) box.get("Width")) * image_width);
                        int bottom = (int) (top + Float.parseFloat((String) box.get("Height")) * image_height);
                        Rect rect = new Rect(left, top, right, bottom);
                        boundingBoxes.add(new BoundingBox(rect, (String) key));
                    }
                }
            }
            catch (ParseException e1){
                e1.printStackTrace();
                Log.e("bad", "rekognition json parse error", e1);
            }
        }
        catch (IOException e2) {
            e2.printStackTrace();
            Log.e("bad", "file reader error", e2);
        }
    }


    public void buildImage(String imagepath, String jsonpath) {
        File image = new File(imagepath);
        if(image.exists()){
            Bitmap bitmap = BitmapFactory.decodeFile(image.getAbsolutePath());

            bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint();
            paint.setColor(Color.rgb(255, 255, 255));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(5);
            parseRekognitionJSON(bitmap);

            for (BoundingBox box : boundingBoxes){
                canvas.drawRect(box.box, paint);
            }

            Log.e("image activity", "screenshot is: " + screenshot);
            screenshot.setImageBitmap(bitmap);

            screenshot.setOnTouchListener(new View.OnTouchListener() {

                Matrix inverse = new Matrix();

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(event.getAction() != MotionEvent.ACTION_DOWN){
                        return false;
                    }

                    screenshot.getImageMatrix().invert(inverse);

                    float[] coords = {event.getX(), event.getY()};

                    inverse.mapPoints(coords);

                    int x = (int)coords[0];
                    int y = (int)coords[1];

                    Log.e("coordinates", "x: " + x + " y: " + y);

                    String found = "";


                    for(BoundingBox box : boundingBoxes){
                        if(box.box.contains(x, y) && !clickedBoxes.contains(box)){
                            clickedBoxes.add(box);
                        }
                    }

                    if (clickedBoxes.size() != 0){
                         //make visual search button visible when item is selected
                        if (vSearch.getVisibility() == View.INVISIBLE) {
                            vSearch.setVisibility(View.VISIBLE);
                        }
                        clicked.setText("you clicked " + clickedBoxes.get(0).tag);
                        lastBoundingBox = clickedBoxes.get(0);
                        clickedBoxes.remove(0);
                    }

                    return true;
                }
            });

        }

    }
    public class BoundingBox {
        Rect box;
        String tag;

        public BoundingBox(Rect box, String tag) {
            this.box = box;
            this.tag = tag;
        }
    }
}



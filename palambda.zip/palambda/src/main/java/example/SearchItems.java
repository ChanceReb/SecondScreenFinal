package example;

/* Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved. */
/* Licensed under the Apache License, Version 2.0. */
/**
 * Download the following artifacts and add to your projects classpath:
 *   o httpclient-4.5.5.jar
 *   o httpcore-4.4.9.jar
 *   o commons-logging-1.2.jar
 *   o json-20180130.jar
 * Put your Secret Key in place of **********
 * Make sure AWSV4Auth Class is available in same package
*/

import java.util.Map;
import java.util.TreeMap;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import example.AWSV4Auth;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class SearchItems implements RequestHandler<Object, String> {

    // CHANGE THESE STRINGS TO QUERY DIFFERENT CATEGORY OF PA API 
    private static final String keyword = "business";
    private static final String searchindex = "FashionWomen";
    private static final String browseNodeId = "1040660";

    // PA API
    private static final String HOST = "webservices.amazon.com";
    private static final String URI_PATH = "/paapi5/searchitems";
    private static final String ACCESS_KEY = "YOUR_ACCESS_KEY_HERE";
    private static final String SECRET_KEY = "YOUR_SECRET_KEY_HERE";
    private static final String REGION = "us-east-1";

    // deepvision
    private static final String DEEPENDPT = "http://api.visualintelligence.deepvisionai.com/search/add_image";
    private static final String DATASETID = "YOUR_DATASET_ID_HERE";
    private static final String dataSetName = "business";
    private static final String APIKEY = "YOUR_DEEPVISION_API_KEY_HERE";

    //S3
    private static final String BUCKET = "YOUR_BUCKET_HERE";
    private static AmazonS3 s3 = AmazonS3ClientBuilder.standard().build();
    private static final String pa_key = "pa_" + searchindex + "_" + keyword; // s3 key for PA JSON response 
    private static final String deepvision_key = "deepvision_" + dataSetName + "_" + searchindex + "_" + keyword;  // s3 key for deepvision JSON response

    public static String buildPayload(String itemPage) {
            String requestPayload;

            requestPayload =         
            "{"
            +" \"Keywords\": \"" + keyword + "\","
            +" \"BrowseNodeId\": \"" + browseNodeId + "\","
            +" \"Resources\": ["
            +"  \"Images.Primary.Large\""
            +" ],"
            +" \"SearchIndex\": \"" + searchindex +"\","
            +" \"ItemPage\": " + itemPage + ","
            +" \"PartnerTag\": \"calpolycecaps-20\","
            +" \"PartnerType\": \"Associates\","
            +" \"Marketplace\": \"www.amazon.com\""
            +"}";

            return requestPayload;
    }

    public static TreeMap<String, String> buildHeader() {
        TreeMap<String, String> headers = new TreeMap<String, String>();
        headers.put("host", HOST);
        headers.put("content-type", "application/json; charset=UTF-8");
        headers.put("x-amz-target", "com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems");
        headers.put("content-encoding", "amz-1.0");

        return headers;
    }

    public static String deepVision(String imageUrl, String alias) throws IOException {
        // should probably not create new client every time
        HttpClient client = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost(DEEPENDPT);
        List<NameValuePair> form = new ArrayList<NameValuePair>();
        form.add(new BasicNameValuePair("dataset_id", DATASETID));
        form.add(new BasicNameValuePair("image", imageUrl));
        form.add(new BasicNameValuePair("alias", alias));
        UrlEncodedFormEntity sendEntity = new UrlEncodedFormEntity(form, Consts.UTF_8);
        httpPost.addHeader("api-key", APIKEY);
        httpPost.setEntity(sendEntity);

        HttpResponse response = client.execute(httpPost);
        HttpEntity resEntity = response.getEntity();
        String jsonResponse = EntityUtils.toString(resEntity, StandardCharsets.UTF_8);
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode == 200) {
            //good
            System.out.println("success");
            System.out.println(jsonResponse);
            return jsonResponse;
        }
        else {
            //print an error somewhere
            System.out.println("failed");
            return "failed";
        }
    }

    // lambda cloudwatch event handler
    @Override
    public String handleRequest(Object input, Context context){
      try {
         paRequest();
      }
      catch (Exception e){
         System.out.println("failed");
      }
      return "success";
    }

    
    public static void paRequest() throws Exception {
        // string to hold full 10 page json response from pa api
        String fulljson = "{\"PA Data\": {";
        String deepvisionjson = "";

        // for ItemPage [1 - 10]
        for (Integer i = 1; i <= 10; i++) {
            String requestPayload = buildPayload(i.toString());
            TreeMap<String, String> headers = buildHeader();
    
            AWSV4Auth awsv4Auth =
                new AWSV4Auth.Builder(ACCESS_KEY, SECRET_KEY)
                    .path(URI_PATH)
                    .region(REGION)
                    .service("ProductAdvertisingAPI")
                    .httpMethodName("POST")
                    .headers(headers)
                    .payload(requestPayload)
                    .build();

            // query pa api with http client
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost httpPost = new HttpPost("https://" + HOST + URI_PATH);
            httpPost.setEntity(new StringEntity(requestPayload));
            Map<String, String> header = awsv4Auth.getHeaders();
            for (Map.Entry<String, String> entrySet : header.entrySet()) {
                httpPost.addHeader(entrySet.getKey(), entrySet.getValue());
            }
            HttpResponse response = client.execute(httpPost);
            HttpEntity entity = response.getEntity();
            String jsonResponse = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            int statusCode = response.getStatusLine().getStatusCode();
            // query success
            if(statusCode == 200) {
                System.out.println("Successfully received response from Product Advertising API.");
                // append one page of pa response to full json
                JSONObject json = new JSONObject(jsonResponse);                   
                fulljson += ("\"Page " + i.toString() + "\": ");
                fulljson += json.toString(3);
                fulljson += ",\n";

                // parse response for deep vision request
                JSONArray items = json.getJSONObject("SearchResult").getJSONArray("Items");
                for (int x = 0; x < items.length(); x++){
                   JSONObject item = items.getJSONObject(x);
                   String asin = item.getString("ASIN");
                   String imageurl = item.getJSONObject("Images").getJSONObject("Primary").getJSONObject("Large").getString("URL");
                   String alias = asin + " " + imageurl;
                   deepvisionjson += deepVision(imageurl, alias); 
                   deepvisionjson += "\n";
                }         
            } 
            // query fail
            else {
                JSONObject json = new JSONObject(jsonResponse);
                if(json.has("Errors")) {
                    JSONArray errorArray = json.getJSONArray("Errors");
                    for(int j = 0; j < errorArray.length(); j++) {
                        JSONObject e = errorArray.getJSONObject(j);
                        System.out.println("Error Code: "+e.get("Code")+", Message: "+e.get("Message"));
                    }
                } 
                else {
                    System.out.println("Error Code: InternalFailure, Message: The request processing has failed because of an unknown error, exception or failure. Please retry again.");
                }
            }
            // have to wait minimum 5 seconds between calls to pa api
            Thread.sleep(5000);
        }
        fulljson += "}\n}";

        // put PA API result json and deep vision json response into s3 bucket
        InputStream stream = new ByteArrayInputStream(fulljson.getBytes(StandardCharsets.UTF_8));
        ObjectMetadata om = new ObjectMetadata();
        om.setContentLength(fulljson.length());
        om.setContentType("json");
        InputStream stream2 = new ByteArrayInputStream(deepvisionjson.getBytes(StandardCharsets.UTF_8));
        ObjectMetadata om2 = new ObjectMetadata();
        om2.setContentLength(deepvisionjson.length());
        om2.setContentType("json");
        try {
            s3.putObject(BUCKET, pa_key, stream, om);
            s3.putObject(BUCKET, deepvision_key, stream2, om2);
        }
        catch (AmazonServiceException e)
        {
            System.err.println(e.getErrorMessage());
            System.exit(1);
        }
    }
}

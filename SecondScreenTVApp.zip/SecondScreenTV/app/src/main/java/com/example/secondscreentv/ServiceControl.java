package com.example.secondscreentv;

import android.app.Activity;
import android.content.Context;

import com.amazon.whisperplay.fling.media.service.CustomMediaPlayer;

public interface ServiceControl extends CustomMediaPlayer {
    public void setContext(Context context);
    public void setActivity(Activity activity);
}
